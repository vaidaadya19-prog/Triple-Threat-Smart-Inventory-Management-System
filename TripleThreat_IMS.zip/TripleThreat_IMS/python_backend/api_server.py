# api_server.py
from flask import Flask, jsonify, request
from flask_cors import CORS
import os
from pipeline import InventoryPipeline

app = Flask(__name__)
CORS(app)

# ── Load pipeline once on startup ─────────────────────────────
pipeline = InventoryPipeline()
pipeline.load_data()

# Train models automatically if not already trained
if not os.path.exists("models/kmeans_model.pkl"):
    print("🧠 First run — training all models...")
    pipeline.train_all()

# ── Routes ────────────────────────────────────────────────────

@app.route("/api/status", methods=["GET"])
def status():
    return jsonify({
        "status": "running",
        "records": len(pipeline.df)
    })

@app.route("/api/summary", methods=["GET"])
def get_summary():
    return jsonify(pipeline.get_summary())

@app.route("/api/train", methods=["POST"])
def train():
    c, f, r = pipeline.train_all()
    return jsonify({
        "message": "Training complete!",
        "clusters" : len(c),
        "forecasts": len(f),
        "classifier_accuracy": r["accuracy"]
    })

@app.route("/api/clusters", methods=["GET"])
def get_clusters():
    results = pipeline.clusterer.train(pipeline.df)
    return jsonify(results)

@app.route("/api/forecast", methods=["GET"])
def get_forecast():
    results = pipeline.forecaster.train(pipeline.df)
    # Return top 20 for display
    return jsonify(results[:20])

@app.route("/api/risk", methods=["GET"])
def get_risk():
    delay = request.args.get(
        "supplier_delay", default=None, type=int)

    if delay:
        results = pipeline.classifier.what_if_analysis(
            pipeline.df, delay)
    else:
        results = pipeline.classifier.predict_risk(pipeline.df)

    return jsonify(results)

@app.route("/api/categories", methods=["GET"])
def get_categories():
    df = pipeline.df
    cats = df.groupby("category").agg(
        total_products  =("product_id", "count"),
        avg_price       =("price", "mean"),
        total_stock     =("current_stock", "sum"),
        at_risk         =("is_stockout_risk", "sum")
    ).reset_index()
    cats["avg_price"] = cats["avg_price"].round(2)
    return jsonify(cats.to_dict(orient="records"))

@app.route("/api/status_breakdown", methods=["GET"])
def get_status_breakdown():
    df = pipeline.df
    breakdown = df.groupby("status").agg(
        count        =("product_id", "count"),
        total_stock  =("current_stock", "sum"),
        avg_price    =("price", "mean")
    ).reset_index()
    breakdown["avg_price"] = breakdown["avg_price"].round(2)
    return jsonify(breakdown.to_dict(orient="records"))

@app.route("/api/predict_new", methods=["POST"])
def predict_new_product():
    """Takes a new product's details and predicts its risk + cluster."""
    data = request.get_json()

    try:
        # ── Build a single-row dataframe ──────────────────────
        new_product = pd.DataFrame([{
            "product_id":           "NEW-001",
            "name":                 data.get("name", "New Product"),
            "price":                float(data.get("price", 0)),
            "current_stock":        int(data.get("current_stock", 0)),
            "lead_time_days":       int(data.get("lead_time_days", 7)),
            "days_since_last_order":int(data.get("days_since_last_order", 30)),
            "supplier_reliability": float(data.get("supplier_reliability", 0.75)),
            "sales_volatility":     float(data.get("sales_volatility", 1.0)),
            "Reorder_Level":        int(data.get("reorder_level", 20)),
            "daily_sales":          int(data.get("daily_sales", 10)),
            "is_weekend":           0,
            "is_holiday":           0,
            "day":                  0,
            "category":             data.get("category", "General"),
            "status":               "Active",
            "is_stockout_risk":     0
        }])

        # ── Risk Prediction ───────────────────────────────────
        feature_cols = [
            "current_stock", "days_since_last_order",
            "supplier_reliability", "lead_time_days",
            "sales_volatility", "price"
        ]
        import joblib
        rf_model = joblib.load("models/rf_classifier.pkl")
        X = new_product[feature_cols]
        risk_prob = float(rf_model.predict_proba(X)[0][1])
        risk_level = (
            "HIGH"   if risk_prob >= 0.7 else
            "MEDIUM" if risk_prob >= 0.4 else
            "LOW"
        )

        # ── Cluster Prediction ────────────────────────────────
        kmeans  = joblib.load("models/kmeans_model.pkl")
        scaler  = joblib.load("models/cluster_scaler.pkl")
        cluster_features = ["price", "lead_time_days", "sales_volatility"]
        X_cluster = scaler.transform(
            new_product[cluster_features])
        cluster_id = int(kmeans.predict(X_cluster)[0])

        # Map cluster to label
        centroids = pd.DataFrame(
            scaler.inverse_transform(kmeans.cluster_centers_),
            columns=cluster_features
        )
        label_map = {}
        for i in range(len(centroids)):
            price_rank     = centroids["price"].rank()[i]
            volatility_rank = centroids["sales_volatility"].rank()[i]
            n = len(centroids)
            if price_rank == n:
                label_map[i] = "High-Value / Slow-Moving"
            elif volatility_rank == n:
                label_map[i] = "Unpredictable / Critical"
            else:
                label_map[i] = "Cheap / Fast-Moving"

        cluster_label = label_map.get(cluster_id, "Unknown")

        # ── Stockout rule-based check ─────────────────────────
        is_stockout = int(data.get("current_stock", 0)) < \
                      int(data.get("reorder_level", 20))

        return jsonify({
            "product_name":    data.get("name", "New Product"),
            "risk_probability": round(risk_prob * 100, 1),
            "risk_level":      risk_level,
            "cluster_id":      cluster_id,
            "cluster_label":   cluster_label,
            "is_stockout_risk": is_stockout,
            "message": (
                f"⚠️ HIGH RISK! Order immediately." if risk_level == "HIGH" else
                f"🟡 Monitor closely."              if risk_level == "MEDIUM" else
                f"✅ Stock levels are safe."
            )
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500
@app.route("/api/chat", methods=["POST"])
def chat():
    """AI Chatbot endpoint that answers inventory questions."""
    data = request.get_json()
    question = data.get("question", "").lower().strip()
    df = pipeline.df

    try:
        # ── Get live stats ────────────────────────────────────
        total_products   = int(df["product_id"].nunique())
        total_value      = round(float((df["current_stock"] * df["price"]).sum()), 2)
        high_risk        = int(df["is_stockout_risk"].sum())
        low_risk         = total_products - high_risk
        avg_reliability  = round(float(df["supplier_reliability"].mean()), 2)
        active           = int((df["status"] == "Active").sum())
        backordered      = int((df["status"] == "Backordered").sum())
        discontinued     = int((df["status"] == "Discontinued").sum())

        # Top 5 high risk products
        high_risk_products = df[df["is_stockout_risk"] == 1].nlargest(
            5, "price")[["name", "current_stock", "price"]].to_dict(orient="records")

        # Category breakdown
        cat_risk = df.groupby("category")["is_stockout_risk"].sum().to_dict()
        best_category = min(cat_risk, key=cat_risk.get)
        worst_category = max(cat_risk, key=cat_risk.get)

        # ── Simple Questions ──────────────────────────────────
        if any(w in question for w in ["total products", "how many products", "product count"]):
            answer = f"📦 There are {total_products} products in your inventory."

        elif any(w in question for w in ["stock value", "total value", "worth"]):
            answer = f"💰 Your total inventory value is ${total_value:,.2f}."

        elif any(w in question for w in ["high risk", "at risk", "stockout risk"]):
            answer = f"🚨 {high_risk} out of {total_products} products are at HIGH stockout risk. That's {round(high_risk/total_products*100, 1)}% of your inventory!"

        elif any(w in question for w in ["safe", "low risk", "not at risk"]):
            answer = f"✅ {low_risk} products are at LOW risk and stock levels are safe."

        elif any(w in question for w in ["active"]):
            answer = f"✅ {active} products are currently Active."

        elif any(w in question for w in ["backordered", "backorder"]):
            answer = f"⏳ {backordered} products are currently Backordered."

        elif any(w in question for w in ["discontinued"]):
            answer = f"🚫 {discontinued} products are Discontinued."

        elif any(w in question for w in ["reliability", "supplier"]):
            answer = f"🤝 Average supplier reliability is {avg_reliability} out of 1.0."

        # ── Smart Questions ───────────────────────────────────
        elif any(w in question for w in ["reorder", "order now", "buy", "purchase"]):
            items = "\n".join([f"• {p['name']} (Stock: {p['current_stock']}, Price: ${p['price']})"
                              for p in high_risk_products])
            answer = f"🛒 Top 5 products to reorder immediately:\n{items}"

        elif any(w in question for w in ["best category", "performing", "best"]):
            answer = f"🏆 Best performing category is **{best_category}** with fewest stockout risks!"

        elif any(w in question for w in ["worst category", "problem", "worst"]):
            answer = f"⚠️ Most at-risk category is **{worst_category}** with most stockout issues."

        elif any(w in question for w in ["category", "categories"]):
            breakdown = "\n".join([f"• {cat}: {risk} at-risk products"
                                  for cat, risk in cat_risk.items()])
            answer = f"📊 Risk breakdown by category:\n{breakdown}"

        elif any(w in question for w in ["expensive", "costly", "highest price", "most expensive"]):
            top = df.nlargest(3, "price")[["name", "price"]].to_dict(orient="records")
            items = "\n".join([f"• {p['name']}: ${p['price']}" for p in top])
            answer = f"💎 Top 3 most expensive products:\n{items}"

        elif any(w in question for w in ["cheapest", "lowest price", "cheap"]):
            bottom = df.nsmallest(3, "price")[["name", "price"]].to_dict(orient="records")
            items = "\n".join([f"• {p['name']}: ${p['price']}" for p in bottom])
            answer = f"💵 Top 3 cheapest products:\n{items}"

        elif any(w in question for w in ["summary", "overview", "report"]):
            answer = (f"📋 Inventory Summary:\n"
                     f"• Total Products: {total_products}\n"
                     f"• Total Value: ${total_value:,.2f}\n"
                     f"• High Risk Items: {high_risk}\n"
                     f"• Active: {active} | Backordered: {backordered}\n"
                     f"• Best Category: {best_category}\n"
                     f"• Avg Supplier Reliability: {avg_reliability}")

        elif any(w in question for w in ["hello", "hi", "hey"]):
            answer = "👋 Hello! I'm your Inventory AI Assistant! Ask me anything about your stock, risks, or recommendations!"

        elif any(w in question for w in ["help", "what can you do", "capabilities"]):
            answer = ("🤖 I can answer questions like:\n"
                     "• How many products are at risk?\n"
                     "• What is the total stock value?\n"
                     "• Which products should I reorder?\n"
                     "• What is the best/worst category?\n"
                     "• Give me a summary\n"
                     "• Which products are most expensive?")

        else:
            answer = ("🤔 I didn't quite understand that. Try asking:\n"
                     "• 'How many products are at risk?'\n"
                     "• 'What is the total stock value?'\n"
                     "• 'Which products should I reorder?'\n"
                     "• 'Give me a summary'")

        return jsonify({"answer": answer, "status": "ok"})

    except Exception as e:
        return jsonify({"answer": f"❌ Error: {str(e)}", "status": "error"})
if __name__ == "__main__":
    app.run(debug=True, port=5000)