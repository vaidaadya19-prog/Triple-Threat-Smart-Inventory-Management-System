package gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import org.json.simple.*;
import org.json.simple.parser.*;

public class AddProductPanel extends JPanel {

    // ── Form fields ───────────────────────────────────────────
    private JTextField nameField, priceField, stockField,
                       leadTimeField, reorderField,
                       salesField, reliabilityField,
                       volatilityField, daysOrderField;
    private JComboBox<String> categoryBox;
    private JButton predictBtn, clearBtn;

    // ── Result panel ──────────────────────────────────────────
    private JLabel riskLevelLabel, riskProbLabel,
                   clusterLabel, messageLabel;
    private JPanel resultCard;

    public AddProductPanel() {
        setBackground(new Color(15, 23, 42));
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(buildHeader(),     BorderLayout.NORTH);
        add(buildMainArea(),   BorderLayout.CENTER);
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);

        JLabel title = new JLabel(
            "➕  Add New Product — Instant AI Risk Prediction");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(167, 139, 250));

        JLabel subtitle = new JLabel(
            "Fill in product details and let the ML model " +
            "instantly predict its stockout risk and cluster");
        subtitle.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        subtitle.setForeground(new Color(148, 163, 184));

        JPanel titles = new JPanel(new GridLayout(2, 1));
        titles.setOpaque(false);
        titles.add(title);
        titles.add(subtitle);
        p.add(titles, BorderLayout.CENTER);
        return p;
    }

    private JPanel buildMainArea() {
        JPanel main = new JPanel(new GridLayout(1, 2, 20, 0));
        main.setOpaque(false);

        main.add(buildForm());
        main.add(buildResultPanel());
        return main;
    }

    private JPanel buildForm() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(new Color(30, 41, 59));
        form.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(167, 139, 250), 2, true),
            new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 5, 6, 5);

        // Form title
        JLabel formTitle = new JLabel("📋  Product Details");
        formTitle.setForeground(new Color(167, 139, 250));
        formTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.gridwidth = 2;
        form.add(formTitle, gbc);
        gbc.gridwidth = 1;

        // Fields
        nameField        = addField(form, gbc, 1,
            "Product Name *", "e.g. Basmati Rice");
        priceField       = addField(form, gbc, 2,
            "Unit Price ($) *", "e.g. 5.99");
        stockField       = addField(form, gbc, 3,
            "Current Stock *", "e.g. 50");
        reorderField     = addField(form, gbc, 4,
            "Reorder Level *", "e.g. 20");
        leadTimeField    = addField(form, gbc, 5,
            "Lead Time (days) *", "e.g. 7");
        salesField       = addField(form, gbc, 6,
            "Daily Sales Volume", "e.g. 15");
        reliabilityField = addField(form, gbc, 7,
            "Supplier Reliability (0-1)", "e.g. 0.85");
        volatilityField  = addField(form, gbc, 8,
            "Sales Volatility", "e.g. 2.5");
        daysOrderField   = addField(form, gbc, 9,
            "Days Since Last Order", "e.g. 14");

        // Category dropdown
        gbc.gridx = 0; gbc.gridy = 10;
        JLabel catLabel = new JLabel("Category");
        catLabel.setForeground(new Color(148, 163, 184));
        catLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        form.add(catLabel, gbc);

        gbc.gridx = 1;
        categoryBox = new JComboBox<>(new String[]{
            "Fruits & Vegetables", "Dairy", "Grains & Pulses",
            "Seafood", "Oils & Fats", "Beverages", "Bakery"
        });
        categoryBox.setBackground(new Color(51, 65, 85));
        categoryBox.setForeground(Color.WHITE);
        categoryBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        form.add(categoryBox, gbc);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        btnPanel.setOpaque(false);

        predictBtn = new JButton("🔮  Predict Risk");
        predictBtn.setBackground(new Color(124, 58, 237));
        predictBtn.setForeground(Color.WHITE);
        predictBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        predictBtn.setFocusPainted(false);
        predictBtn.setBorder(new EmptyBorder(10, 25, 10, 25));
        predictBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        predictBtn.addActionListener(e -> predictRisk());

        clearBtn = new JButton("↺  Clear");
        clearBtn.setBackground(new Color(51, 65, 85));
        clearBtn.setForeground(Color.WHITE);
        clearBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        clearBtn.setFocusPainted(false);
        clearBtn.setBorder(new EmptyBorder(10, 25, 10, 25));
        clearBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        clearBtn.addActionListener(e -> clearForm());

        btnPanel.add(predictBtn);
        btnPanel.add(clearBtn);

        gbc.gridx = 0; gbc.gridy = 11;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(15, 5, 5, 5);
        form.add(btnPanel, gbc);

        return form;
    }

    private JTextField addField(JPanel form, GridBagConstraints gbc,
                                 int row, String label, String placeholder) {
        gbc.gridx = 0; gbc.gridy = row;
        JLabel lbl = new JLabel(label);
        lbl.setForeground(new Color(148, 163, 184));
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        form.add(lbl, gbc);

        gbc.gridx = 1;
        JTextField field = new JTextField(placeholder);
        field.setBackground(new Color(51, 65, 85));
        field.setForeground(new Color(148, 163, 184));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setBorder(new CompoundBorder(
            new LineBorder(new Color(71, 85, 105), 1),
            new EmptyBorder(6, 10, 6, 10)
        ));
        field.setCaretColor(Color.WHITE);

        // Clear placeholder on focus
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent e) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(Color.WHITE);
                }
            }
            public void focusLost(java.awt.event.FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(new Color(148, 163, 184));
                }
            }
        });

        form.add(field, gbc);
        return field;
    }

    private JPanel buildResultPanel() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);

        resultCard = new JPanel(new GridBagLayout());
        resultCard.setBackground(new Color(30, 41, 59));
        resultCard.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(51, 65, 85), 2, true),
            new EmptyBorder(30, 30, 30, 30)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 0, 10, 0);

        JLabel waitLabel = new JLabel(
            "🤖  AI Prediction will appear here",
            SwingConstants.CENTER);
        waitLabel.setForeground(new Color(148, 163, 184));
        waitLabel.setFont(new Font("Segoe UI", Font.ITALIC, 16));

        JLabel waitSub = new JLabel(
            "Fill in the form and click Predict Risk",
            SwingConstants.CENTER);
        waitSub.setForeground(new Color(71, 85, 105));
        waitSub.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        // Result labels (hidden initially)
        riskLevelLabel = makeResultLabel("—", 48, Color.WHITE);
        riskProbLabel  = makeResultLabel("Risk Probability: —", 18,
            new Color(148, 163, 184));
        clusterLabel   = makeResultLabel("Cluster: —", 16,
            new Color(99, 179, 237));
        messageLabel   = makeResultLabel("—", 14,
            new Color(148, 163, 184));

        resultCard.add(waitLabel, gbc);
        resultCard.add(waitSub,   gbc);
        resultCard.add(riskLevelLabel, gbc);
        resultCard.add(riskProbLabel,  gbc);
        resultCard.add(clusterLabel,   gbc);
        resultCard.add(messageLabel,   gbc);

        // Hide result labels initially
        riskLevelLabel.setVisible(false);
        riskProbLabel.setVisible(false);
        clusterLabel.setVisible(false);
        messageLabel.setVisible(false);

        wrapper.add(resultCard, BorderLayout.CENTER);
        return wrapper;
    }

    private JLabel makeResultLabel(String text, int size, Color color) {
        JLabel lbl = new JLabel(text, SwingConstants.CENTER);
        lbl.setForeground(color);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, size));
        return lbl;
    }

    private void predictRisk() {
        // Validate required fields
        if (isEmpty(nameField,  "e.g. Basmati Rice") ||
            isEmpty(priceField, "e.g. 5.99") ||
            isEmpty(stockField, "e.g. 50")   ||
            isEmpty(reorderField, "e.g. 20") ||
            isEmpty(leadTimeField, "e.g. 7")) {
            JOptionPane.showMessageDialog(this,
                "Please fill in all required fields (marked with *)",
                "Missing Fields",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        predictBtn.setEnabled(false);
        predictBtn.setText("⏳  Predicting...");

        new SwingWorker<Void, Void>() {
            protected Void doInBackground() throws Exception {
                // Build JSON payload
                String json = String.format(
                    "{\"name\":\"%s\",\"price\":%s," +
                    "\"current_stock\":%s,\"reorder_level\":%s," +
                    "\"lead_time_days\":%s,\"daily_sales\":%s," +
                    "\"supplier_reliability\":%s," +
                    "\"sales_volatility\":%s," +
                    "\"days_since_last_order\":%s," +
                    "\"category\":\"%s\"}",
                    getText(nameField,  "New Product"),
                    getText(priceField, "0"),
                    getText(stockField, "0"),
                    getText(reorderField, "20"),
                    getText(leadTimeField, "7"),
                    getText(salesField, "10"),
                    getText(reliabilityField, "0.75"),
                    getText(volatilityField, "1.0"),
                    getText(daysOrderField, "30"),
                    categoryBox.getSelectedItem()
                );

                // Send POST request
                URL url = new URL(
                    "http://localhost:5000/api/predict_new");
                HttpURLConnection conn =
                    (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty(
                    "Content-Type", "application/json");
                conn.getOutputStream().write(json.getBytes());

                BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null)
                    sb.append(line);
                br.close();

                JSONObject result = (JSONObject)
                    new JSONParser().parse(sb.toString());

                SwingUtilities.invokeLater(() -> {
                    showResult(result);
                    predictBtn.setEnabled(true);
                    predictBtn.setText("🔮  Predict Risk");
                });
                return null;
            }

            protected void done() {
                try { get(); }
                catch (Exception e) {
                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(
                            AddProductPanel.this,
                            "Error: " + e.getMessage(),
                            "Prediction Failed",
                            JOptionPane.ERROR_MESSAGE);
                        predictBtn.setEnabled(true);
                        predictBtn.setText("🔮  Predict Risk");
                    });
                }
            }
        }.execute();
    }

    private void showResult(JSONObject result) {
        String risk = result.get("risk_level").toString();
        double prob = ((Number) result.get("risk_probability"))
            .doubleValue();
        String cluster = result.get("cluster_label").toString();
        String message = result.get("message").toString();

        // Set risk level color
        Color riskColor =
            "HIGH".equals(risk)   ? new Color(239, 68, 68)  :
            "MEDIUM".equals(risk) ? new Color(245, 158, 11) :
                                    new Color(34, 197, 94);

        // Update result card border color
        resultCard.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(riskColor, 3, true),
            new EmptyBorder(30, 30, 30, 30)
        ));

        riskLevelLabel.setText(
            ("HIGH".equals(risk) ? "🔴 " :
             "MEDIUM".equals(risk) ? "🟡 " : "🟢 ") + risk);
        riskLevelLabel.setForeground(riskColor);
        riskProbLabel.setText(
            String.format("Risk Probability: %.1f%%", prob));
        clusterLabel.setText("Cluster: " + cluster);
        messageLabel.setText(message);

        // Show result labels
        riskLevelLabel.setVisible(true);
        riskProbLabel.setVisible(true);
        clusterLabel.setVisible(true);
        messageLabel.setVisible(true);

        resultCard.revalidate();
        resultCard.repaint();
    }

    private void clearForm() {
        nameField.setText("e.g. Basmati Rice");
        nameField.setForeground(new Color(148, 163, 184));
        priceField.setText("e.g. 5.99");
        priceField.setForeground(new Color(148, 163, 184));
        stockField.setText("e.g. 50");
        stockField.setForeground(new Color(148, 163, 184));
        reorderField.setText("e.g. 20");
        reorderField.setForeground(new Color(148, 163, 184));
        leadTimeField.setText("e.g. 7");
        leadTimeField.setForeground(new Color(148, 163, 184));
        salesField.setText("e.g. 15");
        salesField.setForeground(new Color(148, 163, 184));
        reliabilityField.setText("e.g. 0.85");
        reliabilityField.setForeground(new Color(148, 163, 184));
        volatilityField.setText("e.g. 2.5");
        volatilityField.setForeground(new Color(148, 163, 184));
        daysOrderField.setText("e.g. 14");
        daysOrderField.setForeground(new Color(148, 163, 184));
        categoryBox.setSelectedIndex(0);

        riskLevelLabel.setVisible(false);
        riskProbLabel.setVisible(false);
        clusterLabel.setVisible(false);
        messageLabel.setVisible(false);

        resultCard.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(51, 65, 85), 2, true),
            new EmptyBorder(30, 30, 30, 30)
        ));
        resultCard.revalidate();
        resultCard.repaint();
    }

    private boolean isEmpty(JTextField f, String placeholder) {
        return f.getText().trim().isEmpty() ||
               f.getText().equals(placeholder);
    }

    private String getText(JTextField f, String placeholder) {
        String t = f.getText().trim();
        return (t.isEmpty() || t.equals(placeholder))
            ? placeholder : t;
    }
}