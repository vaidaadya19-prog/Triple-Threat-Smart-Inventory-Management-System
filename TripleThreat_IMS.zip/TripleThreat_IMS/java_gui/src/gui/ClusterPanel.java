package gui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import org.json.simple.*;
import org.json.simple.parser.*;

public class ClusterPanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JLabel statusLabel;

    public ClusterPanel() {
        setBackground(new Color(15, 23, 42));
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(buildHeader(),  BorderLayout.NORTH);
        add(buildTable(),   BorderLayout.CENTER);
        add(buildFooter(),  BorderLayout.SOUTH);
        loadData();
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);

        JLabel title = new JLabel(
            "🔵  Intelligent Product Clustering — K-Means ABC Analysis");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(99, 179, 237));

        JLabel subtitle = new JLabel(
            "Products grouped by Price × Lead Time × Sales Volatility");
        subtitle.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        subtitle.setForeground(new Color(148, 163, 184));

        JPanel titles = new JPanel(new GridLayout(2, 1));
        titles.setOpaque(false);
        titles.add(title);
        titles.add(subtitle);

        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.setBackground(new Color(49, 130, 206));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        refreshBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        refreshBtn.setBorder(new EmptyBorder(8, 18, 8, 18));
        refreshBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        refreshBtn.addActionListener(e -> loadData());

        p.add(titles,     BorderLayout.CENTER);
        p.add(refreshBtn, BorderLayout.EAST);
        return p;
    }

    private JScrollPane buildTable() {
        String[] cols = {
            "Product ID", "Name", "Category",
            "Price ($)", "Lead Time (days)",
            "Volatility", "Cluster", "Category Label"
        };
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        styleTable();

        // Color rows by cluster label
        table.setDefaultRenderer(Object.class,
            new DefaultTableCellRenderer() {
                public Component getTableCellRendererComponent(
                        JTable t, Object val, boolean sel,
                        boolean foc, int row, int col) {
                    super.getTableCellRendererComponent(
                        t, val, sel, foc, row, col);
                    String cat = "";
                    if (t.getModel().getRowCount() > row)
                        cat = t.getModel().getValueAt(row, 7).toString();
                    setBackground(
                        cat.contains("High-Value")      ?
                            new Color(49, 46, 129) :
                        cat.contains("Cheap")           ?
                            new Color(20, 83, 45)  :
                        cat.contains("Unpredictable")   ?
                            new Color(92, 45, 45)  :
                            new Color(30, 41, 59)
                    );
                    setForeground(Color.WHITE);
                    setBorder(new EmptyBorder(0, 10, 0, 10));
                    return this;
                }
            });

        JScrollPane sp = new JScrollPane(table);
        sp.getViewport().setBackground(new Color(30, 41, 59));
        sp.setBorder(new LineBorder(new Color(51, 65, 85)));
        return sp;
    }

    private JPanel buildFooter() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        p.setOpaque(false);

        addLegend(p, "🟣  High-Value / Slow-Moving",  new Color(49, 46, 129));
        addLegend(p, "🟢  Cheap / Fast-Moving",        new Color(20, 83, 45));
        addLegend(p, "🔴  Unpredictable / Critical",   new Color(92, 45, 45));

        statusLabel = new JLabel("Loading...");
        statusLabel.setForeground(new Color(148, 163, 184));
        statusLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        p.add(Box.createHorizontalStrut(20));
        p.add(statusLabel);
        return p;
    }

    private void addLegend(JPanel p, String text, Color color) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setOpaque(true);
        lbl.setBackground(color);
        lbl.setBorder(new EmptyBorder(4, 8, 4, 8));
        p.add(lbl);
    }

    private void styleTable() {
        table.setBackground(new Color(30, 41, 59));
        table.setForeground(Color.WHITE);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32);
        table.setGridColor(new Color(51, 65, 85));
        table.setSelectionBackground(new Color(66, 153, 225));
        table.getTableHeader().setBackground(new Color(51, 65, 85));
        table.getTableHeader().setForeground(new Color(148, 163, 184));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setPreferredSize(new Dimension(0, 40));
    }

    private void loadData() {
        statusLabel.setText("⏳ Loading cluster data...");
        new SwingWorker<Void, Void>() {
            protected Void doInBackground() throws Exception {
                String raw = ApiClient.getRaw("/clusters");
                JSONArray data = (JSONArray)
                    new JSONParser().parse(raw);
                SwingUtilities.invokeLater(() -> {
                    model.setRowCount(0);
                    for (Object obj : data) {
                        JSONObject item = (JSONObject) obj;
                        model.addRow(new Object[]{
                            item.get("product_id"),
                            item.get("name"),
                            item.get("category") != null ?
                                item.get("category") : "—",
                            String.format("$%.2f",
                                ((Number) item.get("price"))
                                .doubleValue()),
                            item.get("lead_time_days") + " days",
                            String.format("%.2f",
                                ((Number) item.get("sales_volatility"))
                                .doubleValue()),
                            item.get("cluster"),
                            item.get("cluster_label")
                        });
                    }
                    statusLabel.setText(
                        "✅ " + data.size() + " products clustered");
                });
                return null;
            }
            protected void done() {
                try { get(); }
                catch (Exception e) {
                    statusLabel.setText("❌ Error: " + e.getMessage());
                }
            }
        }.execute();
    }
}