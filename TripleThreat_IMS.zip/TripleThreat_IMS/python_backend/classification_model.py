# classification_model.py
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import joblib
import os

class StockoutRiskClassifier:
    """Predicts stockout risk using Random Forest Classification."""

    def __init__(self):
        self.model = RandomForestClassifier(
            n_estimators=100, random_state=42, class_weight="balanced"
        )
        self.feature_cols = [
            "current_stock", "days_since_last_order",
            "supplier_reliability", "lead_time_days",
            "sales_volatility", "price"
        ]

    def train(self, df):
        # One row per product
        product_df = df.drop_duplicates(
            subset="product_id").reset_index(drop=True)

        X = product_df[self.feature_cols]
        y = product_df["is_stockout_risk"]

        # Handle case where dataset is small
        test_size = 0.2 if len(product_df) > 10 else 0.1

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42
        )

        self.model.fit(X_train, y_train)
        y_pred = self.model.predict(X_test)

        report = classification_report(
            y_test, y_pred, output_dict=True, zero_division=0)
        cm = confusion_matrix(y_test, y_pred).tolist()

        os.makedirs("models", exist_ok=True)
        joblib.dump(self.model, "models/rf_classifier.pkl")

        return {
            "accuracy": round(report["accuracy"], 3),
            "confusion_matrix": cm,
            "feature_importance": dict(zip(
                self.feature_cols,
                [round(float(x), 3) for x in self.model.feature_importances_]
            ))
        }

    def predict_risk(self, df):
        """Returns risk level and probability for each product."""
        self.model = joblib.load("models/rf_classifier.pkl")

        product_df = df.drop_duplicates(
            subset="product_id").reset_index(drop=True)

        X = product_df[self.feature_cols]
        probabilities = self.model.predict_proba(X)[:, 1]

        product_df = product_df.copy()
        product_df["risk_probability"] = probabilities
        product_df["risk_level"] = pd.cut(
            probabilities,
            bins=[0, 0.4, 0.7, 1.01],
            labels=["LOW", "MEDIUM", "HIGH"]
        )

        return product_df[[
            "product_id", "name", "category",
            "current_stock", "risk_probability", "risk_level"
        ]].to_dict(orient="records")

    def what_if_analysis(self, df, supplier_delay_days):
        """What-If toggle: change supplier delay and see risk change."""
        self.model = joblib.load("models/rf_classifier.pkl")

        product_df = df.drop_duplicates(
            subset="product_id").reset_index(drop=True).copy()

        # Override lead time with new delay
        product_df["lead_time_days"] = supplier_delay_days

        X = product_df[self.feature_cols]
        probabilities = self.model.predict_proba(X)[:, 1]

        product_df["risk_probability"] = probabilities
        product_df["risk_level"] = pd.cut(
            probabilities,
            bins=[0, 0.4, 0.7, 1.01],
            labels=["LOW", "MEDIUM", "HIGH"]
        )

        return product_df[[
            "product_id", "name", "category",
            "current_stock", "risk_probability", "risk_level"
        ]].to_dict(orient="records")