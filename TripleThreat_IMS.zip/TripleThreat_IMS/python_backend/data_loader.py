# data_loader.py
import pandas as pd
import numpy as np
import os

def load_inventory_data(filepath=None):
    if filepath is None:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        filepath = os.path.join(base_dir, "data", "Inventory_Management.csv")

    df = pd.read_csv(filepath)

    # ── 1. Clean Unit_Price (remove $ sign) ──────────────────────
    df["Unit_Price"] = df["Unit_Price"].str.replace("$", "", regex=False).astype(float)

    # ── 2. Drop the 1 null in Category ───────────────────────────
    df = df.dropna(subset=["Catagory"]).reset_index(drop=True)

    # ── 3. Parse dates ────────────────────────────────────────────
    for col in ["Date_Received", "Last_Order_Date", "Expiration_Date"]:
        df[col] = pd.to_datetime(df[col], errors="coerce")

    # ── 4. Engineer features ──────────────────────────────────────

    # Lead time = days between last order and date received
    df["lead_time_days"] = (
        df["Date_Received"] - df["Last_Order_Date"]
    ).dt.days.abs().fillna(7).clip(1, 30).astype(int)

    # Days since last order
    latest_date = df["Last_Order_Date"].max()
    df["days_since_last_order"] = (
        latest_date - df["Last_Order_Date"]
    ).dt.days.fillna(30).astype(int)

    # Supplier reliability score (0.5–1.0)
    supplier_stats = df.groupby("Supplier_ID")["lead_time_days"].std().fillna(1)
    supplier_reliability = (1 / (1 + supplier_stats)).clip(0.5, 1.0)
    df["supplier_reliability"] = df["Supplier_ID"].map(supplier_reliability).fillna(0.75)

    # Sales volatility from Inventory_Turnover_Rate
    df["sales_volatility"] = (df["Inventory_Turnover_Rate"] / 10.0).clip(0.5, 8.0)

    # Weekend / holiday flags from Last_Order_Date
    df["is_weekend"] = df["Last_Order_Date"].dt.dayofweek.isin([5, 6]).astype(int)
    df["is_holiday"] = 0

    # Day ordinal for regression time axis
    min_date = df["Last_Order_Date"].min()
    df["day"] = (df["Last_Order_Date"] - min_date).dt.days.fillna(0).astype(int)

    # ── 5. Stockout Risk label ────────────────────────────────────
    df["is_stockout_risk"] = (
        df["Stock_Quantity"] < df["Reorder_Level"]
    ).astype(int)

    # ── 6. Rename columns to match model expectations ─────────────
    df = df.rename(columns={
        "Product_ID":    "product_id",
        "Product_Name":  "name",
        "Unit_Price":    "price",
        "Stock_Quantity":"current_stock",
        "Sales_Volume":  "daily_sales",
        "Catagory":      "category",
        "Status":        "status"
    })

    print(f"✅ Loaded {len(df)} products from Kaggle dataset.")
    print(f"   Stockout risk items : {df['is_stockout_risk'].sum()} / {len(df)}")
    print(f"   Categories          : {df['category'].nunique()}")

    return df


if __name__ == "__main__":
    df = load_inventory_data()
    print(df[["product_id", "name", "price", "current_stock",
              "lead_time_days", "sales_volatility",
              "supplier_reliability", "is_stockout_risk"]].head(10))