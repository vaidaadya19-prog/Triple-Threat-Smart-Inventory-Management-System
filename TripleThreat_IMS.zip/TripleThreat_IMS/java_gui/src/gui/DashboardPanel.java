package gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import org.json.simple.*;
import org.json.simple.parser.*;

public class DashboardPanel extends JPanel {

    private JLabel totalProductsLabel, stockValueLabel,
                   highRiskLabel, reliabilityLabel,
                   activeLabel, backorderedLabel;
    private JButton refreshBtn, trainBtn;
    private JTextArea logArea;

    public DashboardPanel() {
        setBackground(new Color(15, 23, 42));
        setLayout(new BorderLayout(15, 15));
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(buildTopBar(),   BorderLayout.NORTH);
        add(buildKpiCards(), BorderLayout.CENTER);
        add(buildLogPanel(), BorderLayout.SOUTH);
        refresh();
    }

    private JPanel buildTopBar() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        panel.setOpaque(false);

        JLabel title = new JLabel("📊  Dashboard Overview");
title.setFont(new Font("Segoe UI", Font.BOLD, 18));
title.setForeground(new Color(99, 179, 237));

        refreshBtn = makeButton("🔄  Refresh",       new Color(49, 130, 206));
        trainBtn   = makeButton("🧠  Retrain Models", new Color(72, 187, 120));

        refreshBtn.addActionListener(e -> refresh());
        trainBtn.addActionListener(e -> trainModels());

        panel.add(title);
        panel.add(Box.createHorizontalStrut(30));
        panel.add(refreshBtn);
        panel.add(trainBtn);
        return panel;
    }

    private JPanel buildKpiCards() {
        JPanel grid = new JPanel(new GridLayout(2, 3, 15, 15));
        grid.setOpaque(false);

        totalProductsLabel = makeCard(grid, "📦  Total Products",
            "—", new Color(66, 153, 225));
        stockValueLabel    = makeCard(grid, "💰  Total Stock Value",
            "—", new Color(72, 187, 120));
        highRiskLabel      = makeCard(grid, "🚨  High Risk Items",
            "—", new Color(245, 101, 101));
        reliabilityLabel   = makeCard(grid, "🤝  Avg Reliability",
            "—", new Color(237, 137, 54));
        activeLabel        = makeCard(grid, "✅  Active Products",
            "—", new Color(154, 230, 180));
        backorderedLabel   = makeCard(grid, "⏳  Backordered",
            "—", new Color(252, 211, 77));

        return grid;
    }

    private JLabel makeCard(JPanel parent, String title,
                            String value, Color accent) {
        JPanel card = new JPanel(new BorderLayout(5, 5));
        card.setBackground(new Color(30, 41, 59));
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accent, 2, true),
            new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setForeground(new Color(148, 163, 184));
        titleLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JLabel valueLbl = new JLabel(value);
        valueLbl.setForeground(Color.WHITE);
        valueLbl.setFont(new Font("Segoe UI", Font.BOLD, 28));

        card.add(titleLbl, BorderLayout.NORTH);
        card.add(valueLbl, BorderLayout.CENTER);
        parent.add(card);
        return valueLbl;
    }

    private JScrollPane buildLogPanel() {
        logArea = new JTextArea(5, 40);
        logArea.setBackground(new Color(15, 23, 42));
        logArea.setForeground(new Color(74, 222, 128));
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setEditable(false);
        logArea.setText("[ System Log — Triple-Threat IMS ]\n");
        JScrollPane sp = new JScrollPane(logArea);
        sp.setBorder(new LineBorder(new Color(51, 65, 85), 1));
        sp.setPreferredSize(new Dimension(0, 130));
        return sp;
    }

    private JButton makeButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBorder(new EmptyBorder(8, 18, 8, 18));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    public void refresh() {
        log("🔄 Refreshing dashboard...");
        new SwingWorker<Void, Void>() {
            protected Void doInBackground() throws Exception {
                String raw = ApiClient.getRaw("/summary");
                JSONObject data = (JSONObject)
                    new JSONParser().parse(raw);
                SwingUtilities.invokeLater(() -> {
                    totalProductsLabel.setText(
                        data.get("total_products").toString());
                    stockValueLabel.setText(
                        "$" + data.get("total_stock_value").toString());
                    highRiskLabel.setText(
                        data.get("high_risk_count").toString());
                    reliabilityLabel.setText(
                        data.get("avg_supplier_reliability").toString());
                    activeLabel.setText(
                        data.get("active_products").toString());
                    backorderedLabel.setText(
                        data.get("backordered_products").toString());
                    log("✅ Dashboard refreshed successfully.");
                });
                return null;
            }
            protected void done() {
                try { get(); }
                catch (Exception e) {
                    log("❌ Error: " + e.getMessage());
                }
            }
        }.execute();
    }

    private void trainModels() {
        log("🧠 Retraining all models... please wait.");
        trainBtn.setEnabled(false);
        new SwingWorker<Void, Void>() {
            protected Void doInBackground() throws Exception {
                String result = ApiClient.postTrain();
                SwingUtilities.invokeLater(() -> {
                    log("✅ " + result);
                    trainBtn.setEnabled(true);
                });
                return null;
            }
            protected void done() {
                try { get(); }
                catch (Exception e) {
                    log("❌ Training error: " + e.getMessage());
                    trainBtn.setEnabled(true);
                }
            }
        }.execute();
    }

    private void log(String msg) {
        logArea.append(msg + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }
}