# pipeline.py
import pandas as pd
import os
from data_loader import load_inventory_data
from clustering_model import InventoryClusterer
from regression_model import DemandForecaster
from classification_model import StockoutRiskClassifier

class InventoryPipeline:
    """Master pipeline: Cluster → Forecast → Classify"""

    def __init__(self):
        self.clusterer  = InventoryClusterer()
        self.forecaster = DemandForecaster()
        self.classifier = StockoutRiskClassifier()
        self.df         = None

    def load_data(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        filepath = os.path.join(base_dir, "data", "Inventory_Management.csv")
        self.df  = load_inventory_data(filepath)
        print(f"✅ Pipeline loaded {len(self.df)} products.")

    def train_all(self):
        if self.df is None:
            self.load_data()

        print("\n🔵 Phase 1: Clustering products...")
        cluster_results = self.clusterer.train(self.df)
        print(f"   ✅ Clustered {len(cluster_results)} products.")

        print("\n🟡 Phase 2: Regression forecasting...")
        forecast_results = self.forecaster.train(self.df)
        print(f"   ✅ Forecasted {len(forecast_results)} products.")

        print("\n🔴 Phase 3: Risk classification...")
        class_results = self.classifier.train(self.df)
        print(f"   ✅ Classifier Accuracy: {class_results['accuracy']}")

        print("\n✅ All 3 models trained and saved to /models/")
        return cluster_results, forecast_results, class_results

    def get_summary(self):
        if self.df is None:
            self.load_data()

        df = self.df
        return {
            "total_products": int(df["product_id"].nunique()),
            "total_stock_value": round(
                float((df["current_stock"] * df["price"]).sum()), 2),
            "high_risk_count": int(df["is_stockout_risk"].sum()),
            "avg_supplier_reliability": round(
                float(df["supplier_reliability"].mean()), 2),
            "total_categories": int(df["category"].nunique()),
            "active_products": int((df["status"] == "Active").sum()),
            "backordered_products": int((df["status"] == "Backordered").sum()),
            "discontinued_products": int((df["status"] == "Discontinued").sum())
        }

    def run_inference(self, supplier_delay=None):
        if self.df is None:
            self.load_data()

        risk_data = (
            self.classifier.what_if_analysis(self.df, supplier_delay)
            if supplier_delay
            else self.classifier.predict_risk(self.df)
        )
        cluster_data = self.clusterer.load_and_predict(self.df)

        return {
            "clusters": cluster_data.to_dict(orient="records"),
            "risks": risk_data
        }


if __name__ == "__main__":
    pipeline = InventoryPipeline()
    pipeline.load_data()
    pipeline.train_all()
    print("\nSummary:", pipeline.get_summary())