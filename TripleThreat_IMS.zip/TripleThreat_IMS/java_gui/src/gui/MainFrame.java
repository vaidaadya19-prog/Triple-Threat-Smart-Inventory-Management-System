package gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class MainFrame extends JFrame {

    private boolean isDarkMode = false;
    private JPanel headerPanel;
    private JTabbedPane tabs;
    private ChatBotPanel chatBotPanel;

    public MainFrame() {
        setTitle("⚡ Triple-Threat Inventory Intelligence System");
        setSize(1280, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(buildHeader(), BorderLayout.NORTH);
        add(buildTabs(),   BorderLayout.CENTER);

        applyTheme();
        setVisible(true);
    }

    private JPanel buildHeader() {
        headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBorder(new EmptyBorder(20, 30, 20, 30));
        headerPanel.setBackground(new Color(10, 15, 30));

        // ── CENTER: Big Title ─────────────────────────────────
        JPanel centerPanel = new JPanel(new GridLayout(2, 1, 0, 5));
        centerPanel.setOpaque(false);

        JLabel title = new JLabel(
            "⚡ Triple-Threat Inventory Intelligence System",
            SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(new Color(99, 179, 237));

        JLabel subtitle = new JLabel(
            "ML-Powered  •  Cluster  •  Forecast  •  Classify  •  Predict",
            SwingConstants.CENTER);
        subtitle.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        subtitle.setForeground(new Color(148, 163, 184));

        centerPanel.add(title);
        centerPanel.add(subtitle);

        // ── RIGHT: Theme Toggle ───────────────────────────────
        JPanel rightPanel = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 0, 0));
        rightPanel.setOpaque(false);

        JToggleButton themeToggle = new JToggleButton("🌙  Dark Mode");
        themeToggle.setSelected(false);
        themeToggle.setBackground(new Color(99, 179, 237));
        themeToggle.setForeground(Color.WHITE);
        themeToggle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        themeToggle.setFocusPainted(false);
        themeToggle.setBorderPainted(false);
        themeToggle.setOpaque(true);
        themeToggle.setPreferredSize(new Dimension(150, 40));
        themeToggle.setCursor(new Cursor(Cursor.HAND_CURSOR));
        themeToggle.addActionListener(e -> {
            isDarkMode = themeToggle.isSelected();
            themeToggle.setText(
                isDarkMode ? "☀️  Light Mode" : "🌙  Dark Mode");
            themeToggle.setBackground(
                isDarkMode ? new Color(51, 65, 85) :
                             new Color(99, 179, 237));
            applyTheme();
        });

        rightPanel.add(themeToggle);

        headerPanel.add(centerPanel, BorderLayout.CENTER);
        headerPanel.add(rightPanel,  BorderLayout.EAST);
        return headerPanel;
    }

    private JTabbedPane buildTabs() {
        tabs = new JTabbedPane(JTabbedPane.TOP);
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabs.setBorder(new EmptyBorder(5, 5, 5, 5));

        chatBotPanel = new ChatBotPanel(isDarkMode);

        tabs.addTab("📊  Dashboard",   new DashboardPanel());
        tabs.addTab("🔵  Clusters",    new ClusterPanel());
        tabs.addTab("📈  Forecast",    new ForecastPanel());
        tabs.addTab("🚨  Risk Guard",  new RiskPanel());
        tabs.addTab("➕  Add Product", new AddProductPanel());
        tabs.addTab("🤖  AI Chatbot",  chatBotPanel);

        // Force tab colors and text colors
        Color[] tabBg = {
            new Color(37, 99, 235),
            new Color(6, 182, 212),
            new Color(16, 185, 129),
            new Color(239, 68, 68),
            new Color(124, 58, 237),
            new Color(139, 92, 246)
        };

        for (int i = 0; i < tabBg.length; i++) {
            tabs.setBackgroundAt(i, tabBg[i]);
            tabs.setForegroundAt(i, Color.WHITE);
        }

        // Make tabs bigger
        tabs.setPreferredSize(new Dimension(0, 45));

        return tabs;
    }

    private void applyTheme() {
        Color bg = isDarkMode ?
            new Color(15, 23, 42) : new Color(240, 245, 255);

        getContentPane().setBackground(bg);
        tabs.setBackground(bg);

        if (chatBotPanel != null)
            chatBotPanel.updateTheme(isDarkMode);

        // Re-apply tab colors (they reset on theme change)
        Color[] tabBg = {
            new Color(37, 99, 235),
            new Color(6, 182, 212),
            new Color(16, 185, 129),
            new Color(239, 68, 68),
            new Color(124, 58, 237),
            new Color(139, 92, 246)
        };
        for (int i = 0; i < tabBg.length; i++) {
            tabs.setBackgroundAt(i, tabBg[i]);
            tabs.setForegroundAt(i, Color.WHITE);
        }

        repaint();
        revalidate();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Use Nimbus look and feel for better tab colors
                for (UIManager.LookAndFeelInfo info :
                        UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (Exception ignored) {}
            new MainFrame();
        });
    }
}