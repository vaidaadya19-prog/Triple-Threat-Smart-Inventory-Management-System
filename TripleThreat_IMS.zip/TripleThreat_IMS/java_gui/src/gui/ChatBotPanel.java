package gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import org.json.simple.*;
import org.json.simple.parser.*;

public class ChatBotPanel extends JPanel {

    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendBtn;
    private boolean isDarkMode;

    public ChatBotPanel(boolean isDarkMode) {
        this.isDarkMode = isDarkMode;
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(20, 20, 20, 20));
        updateTheme();

        add(buildHeader(),  BorderLayout.NORTH);
        add(buildChat(),    BorderLayout.CENTER);
        add(buildInput(),   BorderLayout.SOUTH);

        // Welcome message
        appendMessage("🤖 Bot",
            "👋 Hello! I'm your Inventory AI Assistant!\n" +
            "Ask me anything about your inventory.\n" +
            "Try: 'Give me a summary' or 'Which products should I reorder?'",
            false);
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);

        JLabel title = new JLabel("🤖  Inventory AI Chatbot");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(139, 92, 246));

        JLabel subtitle = new JLabel(
            "Ask questions about your inventory in plain English!");
        subtitle.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        subtitle.setForeground(new Color(148, 163, 184));

        // Quick question buttons
        JPanel quickBtns = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 8, 5));
        quickBtns.setOpaque(false);

        String[] quickQuestions = {
            "📋 Summary", "🚨 High Risk",
            "🛒 Reorder Now", "🏆 Best Category"
        };
        String[] fullQuestions = {
            "Give me a summary",
            "How many products are at high risk?",
            "Which products should I reorder?",
            "What is the best category?"
        };

        for (int i = 0; i < quickQuestions.length; i++) {
            final String q = fullQuestions[i];
            JButton btn = new JButton(quickQuestions[i]);
            btn.setBackground(new Color(139, 92, 246));
            btn.setForeground(Color.WHITE);
            btn.setFont(new Font("Segoe UI", Font.BOLD, 11));
            btn.setFocusPainted(false);
            btn.setBorder(new EmptyBorder(5, 10, 5, 10));
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.addActionListener(e -> sendQuestion(q));
            quickBtns.add(btn);
        }

        JPanel titles = new JPanel(new GridLayout(2, 1));
        titles.setOpaque(false);
        titles.add(title);
        titles.add(subtitle);

        JPanel headerPanel = new JPanel(new BorderLayout(0, 5));
        headerPanel.setOpaque(false);
        headerPanel.add(titles,    BorderLayout.NORTH);
        headerPanel.add(quickBtns, BorderLayout.SOUTH);
        p.add(headerPanel, BorderLayout.CENTER);
        return p;
    }

    private JScrollPane buildChat() {
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);
        chatArea.setBorder(new EmptyBorder(15, 15, 15, 15));
        updateChatTheme();

        JScrollPane sp = new JScrollPane(chatArea);
        sp.setBorder(new LineBorder(new Color(139, 92, 246), 2, true));
        return sp;
    }

    private JPanel buildInput() {
        JPanel p = new JPanel(new BorderLayout(10, 0));
        p.setOpaque(false);

        inputField = new JTextField();
        inputField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        inputField.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(139, 92, 246), 2, true),
            new EmptyBorder(10, 15, 10, 15)
        ));
        inputField.setBackground(isDarkMode ?
            new Color(30, 41, 59) : Color.WHITE);
        inputField.setForeground(isDarkMode ?
            Color.WHITE : new Color(15, 23, 42));
        inputField.setCaretColor(new Color(139, 92, 246));

        // Send on Enter
        inputField.addActionListener(e -> sendMessage());

        sendBtn = new JButton("Send ➤");
        sendBtn.setBackground(new Color(139, 92, 246));
        sendBtn.setForeground(Color.WHITE);
        sendBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        sendBtn.setFocusPainted(false);
        sendBtn.setBorder(new EmptyBorder(10, 25, 10, 25));
        sendBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        sendBtn.addActionListener(e -> sendMessage());

        p.add(inputField, BorderLayout.CENTER);
        p.add(sendBtn,    BorderLayout.EAST);
        return p;
    }

    private void sendMessage() {
        String text = inputField.getText().trim();
        if (text.isEmpty()) return;
        inputField.setText("");
        sendQuestion(text);
    }

    private void sendQuestion(String question) {
        appendMessage("👤 You", question, true);
        sendBtn.setEnabled(false);

        new SwingWorker<Void, Void>() {
            protected Void doInBackground() throws Exception {
                String json = "{\"question\":\"" +
                    question.replace("\"", "'") + "\"}";
                URL url = new URL(
                    "http://localhost:5000/api/chat");
                HttpURLConnection conn =
                    (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty(
                    "Content-Type", "application/json");
                conn.getOutputStream().write(json.getBytes());

                BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null)
                    sb.append(line);
                br.close();

                JSONObject result = (JSONObject)
                    new JSONParser().parse(sb.toString());
                String answer = result.get("answer").toString();

                SwingUtilities.invokeLater(() -> {
                    appendMessage("🤖 Bot", answer, false);
                    sendBtn.setEnabled(true);
                });
                return null;
            }
            protected void done() {
                try { get(); }
                catch (Exception e) {
                    SwingUtilities.invokeLater(() -> {
                        appendMessage("🤖 Bot",
                            "❌ Could not connect. Is the Python server running?",
                            false);
                        sendBtn.setEnabled(true);
                    });
                }
            }
        }.execute();
    }

    private void appendMessage(String sender, String message, boolean isUser) {
        String separator = "\n" + "─".repeat(50) + "\n";
        chatArea.append(separator);
        chatArea.append(sender + ":\n");
        chatArea.append(message + "\n");
        chatArea.setCaretPosition(chatArea.getDocument().getLength());
    }

    public void updateTheme(boolean dark) {
        this.isDarkMode = dark;
        updateTheme();
        updateChatTheme();
        if (inputField != null) {
            inputField.setBackground(dark ?
                new Color(30, 41, 59) : Color.WHITE);
            inputField.setForeground(dark ?
                Color.WHITE : new Color(15, 23, 42));
        }
        repaint();
        revalidate();
    }

    private void updateTheme() {
        setBackground(isDarkMode ?
            new Color(15, 23, 42) : new Color(248, 250, 252));
    }

    private void updateChatTheme() {
        if (chatArea == null) return;
        chatArea.setBackground(isDarkMode ?
            new Color(30, 41, 59) : Color.WHITE);
        chatArea.setForeground(isDarkMode ?
            Color.WHITE : new Color(15, 23, 42));
    }
}