package gui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;
import org.json.simple.*;
import org.json.simple.parser.*;

public class RiskPanel extends JPanel {

    private JTable table;
    private DefaultTableModel model;
    private JSlider delaySlider;
    private JLabel delayLabel, statusLabel;

    public RiskPanel() {
        setBackground(new Color(15, 23, 42));
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(20, 20, 20, 20));

        add(buildHeader(),  BorderLayout.NORTH);
        add(buildTable(),   BorderLayout.CENTER);
        add(buildWhatIf(),  BorderLayout.SOUTH);
        loadRisk(null);
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);

        JLabel title = new JLabel(
            "🚨  Stockout Risk Predictor — Random Forest Classification");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(new Color(252, 129, 74));

        JLabel subtitle = new JLabel(
            "Predicts probability of each product running " +
            "out of stock before next shipment");
        subtitle.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        subtitle.setForeground(new Color(148, 163, 184));

        JPanel titles = new JPanel(new GridLayout(2, 1));
        titles.setOpaque(false);
        titles.add(title);
        titles.add(subtitle);

        JButton refreshBtn = new JButton("🔄 Refresh");
        refreshBtn.setBackground(new Color(220, 38, 38));
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.setFocusPainted(false);
        refreshBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        refreshBtn.setBorder(new EmptyBorder(8, 18, 8, 18));
        refreshBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        refreshBtn.addActionListener(e -> loadRisk(null));

        p.add(titles,     BorderLayout.CENTER);
        p.add(refreshBtn, BorderLayout.EAST);
        return p;
    }

    private JScrollPane buildTable() {
        String[] cols = {
            "Product ID", "Name", "Category",
            "Current Stock", "Risk %", "Risk Level"
        };
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        styleTable();

        // Color rows by risk level
        table.setDefaultRenderer(Object.class,
            new DefaultTableCellRenderer() {
                public Component getTableCellRendererComponent(
                        JTable t, Object val, boolean sel,
                        boolean foc, int row, int col) {
                    super.getTableCellRendererComponent(
                        t, val, sel, foc, row, col);
                    if (t.getModel().getRowCount() > row) {
                        String risk = t.getModel()
                            .getValueAt(row, 5).toString();
                        setBackground(
                            "HIGH".equals(risk)   ?
                                new Color(127, 29, 29)  :
                            "MEDIUM".equals(risk) ?
                                new Color(92, 61, 0)    :
                                new Color(20, 83, 45)
                        );
                    }
                    setForeground(Color.WHITE);
                    setBorder(new EmptyBorder(0, 10, 0, 10));
                    return this;
                }
            });

        JScrollPane sp = new JScrollPane(table);
        sp.getViewport().setBackground(new Color(30, 41, 59));
        sp.setBorder(new LineBorder(new Color(51, 65, 85)));
        return sp;
    }

    private JPanel buildWhatIf() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        outer.setOpaque(false);

        // Legend
        JPanel legend = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        legend.setOpaque(false);
        addLegend(legend, "🔴  HIGH Risk (>70%)",   new Color(127, 29, 29));
        addLegend(legend, "🟡  MEDIUM Risk (40-70%)", new Color(92, 61, 0));
        addLegend(legend, "🟢  LOW Risk (<40%)",     new Color(20, 83, 45));

        statusLabel = new JLabel("Loading...");
        statusLabel.setForeground(new Color(148, 163, 184));
        statusLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        legend.add(Box.createHorizontalStrut(20));
        legend.add(statusLabel);

        // What-If panel
        JPanel whatIf = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        whatIf.setBackground(new Color(30, 41, 59));
        whatIf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(245, 101, 101), 2, true),
            new EmptyBorder(8, 10, 8, 10)
        ));

        JLabel wLabel = new JLabel("⚡  What-If: Supplier Delay  ");
        wLabel.setForeground(new Color(252, 129, 74));
        wLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

        delaySlider = new JSlider(1, 20, 3);
        delaySlider.setBackground(new Color(30, 41, 59));
        delaySlider.setForeground(Color.WHITE);
        delaySlider.setMajorTickSpacing(5);
        delaySlider.setMinorTickSpacing(1);
        delaySlider.setPaintTicks(true);
        delaySlider.setPaintLabels(true);
        delaySlider.setPreferredSize(new Dimension(300, 50));

        delayLabel = new JLabel("3 days");
        delayLabel.setForeground(Color.WHITE);
        delayLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        delayLabel.setPreferredSize(new Dimension(70, 30));

        JButton applyBtn = new JButton("▶  Apply");
        applyBtn.setBackground(new Color(220, 38, 38));
        applyBtn.setForeground(Color.WHITE);
        applyBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        applyBtn.setFocusPainted(false);
        applyBtn.setBorder(new EmptyBorder(8, 20, 8, 20));
        applyBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JButton resetBtn = new JButton("↺  Reset");
        resetBtn.setBackground(new Color(51, 65, 85));
        resetBtn.setForeground(Color.WHITE);
        resetBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        resetBtn.setFocusPainted(false);
        resetBtn.setBorder(new EmptyBorder(8, 20, 8, 20));
        resetBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        delaySlider.addChangeListener(e ->
            delayLabel.setText(delaySlider.getValue() + " days"));
        applyBtn.addActionListener(e ->
            loadRisk(delaySlider.getValue()));
        resetBtn.addActionListener(e -> {
            delaySlider.setValue(3);
            loadRisk(null);
        });

        whatIf.add(wLabel);
        whatIf.add(delaySlider);
        whatIf.add(delayLabel);
        whatIf.add(applyBtn);
        whatIf.add(resetBtn);

        outer.add(legend, BorderLayout.NORTH);
        outer.add(whatIf, BorderLayout.CENTER);
        return outer;
    }

    private void addLegend(JPanel p, String text, Color color) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setOpaque(true);
        lbl.setBackground(color);
        lbl.setBorder(new EmptyBorder(4, 8, 4, 8));
        p.add(lbl);
    }

    private void styleTable() {
        table.setBackground(new Color(30, 41, 59));
        table.setForeground(Color.WHITE);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32);
        table.setGridColor(new Color(51, 65, 85));
        table.setSelectionBackground(new Color(220, 38, 38));
        table.getTableHeader().setBackground(new Color(51, 65, 85));
        table.getTableHeader().setForeground(new Color(148, 163, 184));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setPreferredSize(new Dimension(0, 40));
    }

    public void loadRisk(Integer supplierDelay) {
        if (statusLabel != null)
            statusLabel.setText("⏳ Loading risk data...");
        new SwingWorker<Void, Void>() {
            protected Void doInBackground() throws Exception {
                String endpoint = supplierDelay != null
                    ? "/risk?supplier_delay=" + supplierDelay
                    : "/risk";
                String raw  = ApiClient.getRaw(endpoint);
                JSONArray data = (JSONArray)
                    new JSONParser().parse(raw);
                SwingUtilities.invokeLater(() -> {
                    model.setRowCount(0);
                    for (Object obj : data) {
                        JSONObject item = (JSONObject) obj;
                        double riskPct =
                            ((Number) item.get("risk_probability"))
                            .doubleValue() * 100;
                        model.addRow(new Object[]{
                            item.get("product_id"),
                            item.get("name"),
                            item.get("category") != null ?
                                item.get("category") : "—",
                            item.get("current_stock"),
                            String.format("%.1f%%", riskPct),
                            item.get("risk_level")
                        });
                    }
                    // Sort by risk % descending
                    TableRowSorter<DefaultTableModel> sorter =
                        new TableRowSorter<>(model);
                    table.setRowSorter(sorter);
                    sorter.setSortKeys(List.of(
                        new RowSorter.SortKey(4, SortOrder.DESCENDING)));
                    if (statusLabel != null)
                        statusLabel.setText(
                            "✅ " + data.size() + " products analysed");
                });
                return null;
            }
            protected void done() {
                try { get(); }
                catch (Exception e) {
                    if (statusLabel != null)
                        statusLabel.setText(
                            "❌ Error: " + e.getMessage());
                }
            }
        }.execute();
    }
}