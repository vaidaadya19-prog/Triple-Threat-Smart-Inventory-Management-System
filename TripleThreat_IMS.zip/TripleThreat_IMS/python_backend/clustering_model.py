# clustering_model.py
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import joblib
import os

class InventoryClusterer:
    """Clusters products into strategic groups using K-Means."""

    def __init__(self, n_clusters=3):
        self.n_clusters = n_clusters
        self.scaler = StandardScaler()
        self.model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        self.feature_cols = ["price", "lead_time_days", "sales_volatility"]

    def train(self, df):
        # One row per product
        product_df = df[["product_id", "name", "price",
                          "lead_time_days", "sales_volatility"]].drop_duplicates(
                          subset="product_id").reset_index(drop=True)

        X = self.scaler.fit_transform(product_df[self.feature_cols])
        product_df["cluster"] = self.model.fit_predict(X)

        # Auto-label clusters based on centroid values
        centroids = pd.DataFrame(
            self.scaler.inverse_transform(self.model.cluster_centers_),
            columns=self.feature_cols
        )

        label_map = {}
        for i in range(self.n_clusters):
            price_rank     = centroids["price"].rank()[i]
            volatility_rank = centroids["sales_volatility"].rank()[i]
            if price_rank == self.n_clusters:
                label_map[i] = "High-Value / Slow-Moving"
            elif volatility_rank == self.n_clusters:
                label_map[i] = "Unpredictable / Critical"
            else:
                label_map[i] = "Cheap / Fast-Moving"

        product_df["cluster_label"] = product_df["cluster"].map(label_map)

        # Save models
        os.makedirs("models", exist_ok=True)
        joblib.dump(self.model,  "models/kmeans_model.pkl")
        joblib.dump(self.scaler, "models/cluster_scaler.pkl")

        return product_df[[
            "product_id", "name", "price",
            "lead_time_days", "sales_volatility",
            "cluster", "cluster_label"
        ]].to_dict(orient="records")

    def load_and_predict(self, df):
        self.model  = joblib.load("models/kmeans_model.pkl")
        self.scaler = joblib.load("models/cluster_scaler.pkl")

        product_df = df[["product_id"] + self.feature_cols].drop_duplicates(
            subset="product_id").reset_index(drop=True)

        X = self.scaler.transform(product_df[self.feature_cols])
        product_df["cluster"] = self.model.predict(X)
        return product_df