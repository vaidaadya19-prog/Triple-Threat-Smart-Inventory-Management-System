class InventoryItem:
    def __init__(self, product_id, name, price, current_stock,
                 lead_time_days, sales_volatility, supplier_reliability):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.current_stock = current_stock
        self.lead_time_days = lead_time_days
        self.sales_volatility = sales_volatility
        self.supplier_reliability = supplier_reliability

    def to_dict(self):
        return {
            "product_id": self.product_id,
            "name": self.name,
            "price": self.price,
            "current_stock": self.current_stock,
            "lead_time_days": self.lead_time_days,
            "sales_volatility": self.sales_volatility,
            "supplier_reliability": self.supplier_reliability
        }

    def __repr__(self):
        return f"InventoryItem({self.name}, Stock: {self.current_stock})"


class PremiumItem(InventoryItem):
    def __init__(self, *args, warranty_months=12):
        super().__init__(*args)
        self.warranty_months = warranty_months

    def to_dict(self):
        d = super().to_dict()
        d["warranty_months"] = self.warranty_months
        return d


class FastMovingItem(InventoryItem):
    def __init__(self, *args, reorder_batch_size=100):
        super().__init__(*args)
        self.reorder_batch_size = reorder_batch_size

    def to_dict(self):
        d = super().to_dict()
        d["reorder_batch_size"] = self.reorder_batch_size
        return d