# regression_model.py
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import r2_score
import joblib
import os

class DemandForecaster:
    """Predicts future demand using Polynomial Regression."""

    def __init__(self, degree=2):
        self.degree = degree
        self.poly = PolynomialFeatures(degree=degree)
        self.model = LinearRegression()
        self.feature_cols = ["day", "is_weekend", "is_holiday",
                             "price", "sales_volatility"]

    def train(self, df):
        results = []
        os.makedirs("models", exist_ok=True)

        # Use one row per product (no daily history in Kaggle dataset)
        product_df = df.drop_duplicates(subset="product_id").reset_index(drop=True)

        # Build a mini time-series per product using Sales_Volume + day
        all_X = []
        all_y = []

        for _, row in product_df.iterrows():
            # Simulate 10 time points per product using turnover variation
            for i in range(10):
                simulated_day = int(row["day"]) + i * 3
                is_weekend = 1 if simulated_day % 7 >= 5 else 0
                noise = np.random.normal(0, row["sales_volatility"])
                simulated_sales = max(0, row["daily_sales"] + noise)
                all_X.append([simulated_day, is_weekend, 0,
                               row["price"], row["sales_volatility"]])
                all_y.append(simulated_sales)

        X = np.array(all_X)
        y = np.array(all_y)

        X_poly = self.poly.fit_transform(X)
        self.model.fit(X_poly, y)

        y_pred = self.model.predict(X_poly)
        overall_r2 = round(r2_score(y, y_pred), 3)

        # Now forecast next 7 days per product
        for _, row in product_df.iterrows():
            forecasts = []
            for d in range(1, 8):
                future_day = int(row["day"]) + d
                is_weekend = 1 if future_day % 7 >= 5 else 0
                X_future = np.array([[future_day, is_weekend, 0,
                                      row["price"], row["sales_volatility"]]])
                pred = max(0, int(self.model.predict(
                    self.poly.transform(X_future))[0]))
                forecasts.append({
                    "day": future_day,
                    "predicted_sales": pred
                })

            results.append({
                "product_id": row["product_id"],
                "name": row["name"],
                "category": row["category"],
                "current_sales": int(row["daily_sales"]),
                "r2_score": overall_r2,
                "forecast_next_7_days": forecasts,
                "total_predicted_week": sum(
                    f["predicted_sales"] for f in forecasts)
            })

        joblib.dump((self.poly, self.model), "models/regression_model.pkl")
        return results

    def load_and_forecast(self, row, days_ahead=7):
        self.poly, self.model = joblib.load("models/regression_model.pkl")
        forecasts = []
        for d in range(1, days_ahead + 1):
            future_day = int(row["day"]) + d
            is_weekend = 1 if future_day % 7 >= 5 else 0
            X = np.array([[future_day, is_weekend, 0,
                           row["price"], row["sales_volatility"]]])
            pred = max(0, int(self.model.predict(self.poly.transform(X))[0]))
            forecasts.append(pred)
        return forecasts